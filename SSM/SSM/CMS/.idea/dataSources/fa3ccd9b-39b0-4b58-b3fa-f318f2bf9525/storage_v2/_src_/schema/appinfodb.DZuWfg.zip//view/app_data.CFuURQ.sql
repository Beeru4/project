create view app_data as
select `i`.`id`                  AS `id`,
       `i`.`softwareName`        AS `softwareName`,
       `i`.`APKName`             AS `APKName`,
       `i`.`softwareSize`        AS `softwareSize`,
       `app_flatform`.`flatform` AS `flatform`,
       `level1`.`level1Name`     AS `level1Name`,
       `level2`.`level2Name`     AS `level2Name`,
       `level3`.`level3Name`     AS `level3Name`,
       `app_status`.`stauts`     AS `stauts`,
       `i`.`downloads`           AS `downloads`,
       `v`.`versionNo`           AS `versionNo`
from `appinfodb`.`app_version` `v`
         join `appinfodb`.`app_info` `i`
         join (select `appinfodb`.`data_dictionary`.`valueId`   AS `stautusId`,
                      `appinfodb`.`data_dictionary`.`valueName` AS `stauts`
               from `appinfodb`.`data_dictionary`
               where (`appinfodb`.`data_dictionary`.`typeCode` = 'APP_STATUS')) `APP_STATUS`
         join (select `appinfodb`.`data_dictionary`.`valueId`   AS `flatformid`,
                      `appinfodb`.`data_dictionary`.`valueName` AS `flatform`
               from `appinfodb`.`data_dictionary`
               where (`appinfodb`.`data_dictionary`.`typeCode` = 'APP_FLATFORM')) `APP_FLATFORM`
         join (select `appinfodb`.`app_info`.`id` AS `id`, `appinfodb`.`app_category`.`categoryName` AS `level1Name`
               from `appinfodb`.`app_info`
                        join `appinfodb`.`app_category`
               where (`appinfodb`.`app_info`.`categoryLevel1` = `appinfodb`.`app_category`.`id`)) `level1`
         join (select `appinfodb`.`app_info`.`id` AS `id`, `appinfodb`.`app_category`.`categoryName` AS `level2Name`
               from `appinfodb`.`app_info`
                        join `appinfodb`.`app_category`
               where (`appinfodb`.`app_info`.`categoryLevel2` = `appinfodb`.`app_category`.`id`)) `level2`
         join (select `appinfodb`.`app_info`.`id` AS `id`, `appinfodb`.`app_category`.`categoryName` AS `level3Name`
               from `appinfodb`.`app_info`
                        join `appinfodb`.`app_category`
               where (`appinfodb`.`app_info`.`categoryLevel3` = `appinfodb`.`app_category`.`id`)) `level3`
where ((`i`.`id` = `v`.`appId`) and (`app_status`.`stautusId` = `i`.`status`) and
       (`i`.`flatformId` = `app_flatform`.`flatformid`) and (`i`.`id` = `level1`.`id`) and
       (`i`.`id` = `level2`.`id`) and (`i`.`id` = `level3`.`id`));

-- comment on column app_data.id not supported: 主键id

-- comment on column app_data.softwareName not supported: 软件名称

-- comment on column app_data.APKName not supported: APK名称（唯一）

-- comment on column app_data.softwareSize not supported: 软件大小（单位：M）

-- comment on column app_data.flatform not supported: 类型值Name

-- comment on column app_data.level1Name not supported: 分类名称

-- comment on column app_data.level2Name not supported: 分类名称

-- comment on column app_data.level3Name not supported: 分类名称

-- comment on column app_data.stauts not supported: 类型值Name

-- comment on column app_data.downloads not supported: 下载量（单位：次）

-- comment on column app_data.versionNo not supported: 版本号

